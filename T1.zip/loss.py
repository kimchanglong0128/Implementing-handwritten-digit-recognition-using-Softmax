import numpy as np

# a small number to prevent dividing by zero, maybe useful for you
EPS = 1e-11

class SoftmaxCrossEntropyLoss(object):

    def __init__(self, num_input, num_output, trainable=True):
        """
        Apply a linear transformation to the incoming data: y = Wx + b
        Args:
            num_input: size of each input sample
            num_output: size of each output sample
            trainable: whether if this layer is trainable
        """

        self.num_input = num_input
        self.num_output = num_output
        self.trainable = trainable
        self.XavierInit()

    def forward(self, Input, labels):
        """
          Inputs: (minibatch)
          - Input: (batch_size, 784)
          - labels: the ground truth label, shape (batch_size, )
        """

        ############################################################################
        # 线性变换
        scores = np.dot(Input, self.W) + self.b
        
        # Softmax函数
        exp_scores = np.exp(scores - np.max(scores, axis=1, keepdims=True))
        probs = exp_scores / (np.sum(exp_scores, axis=1, keepdims=True) + EPS)
        
        # 交叉熵损失
        N = Input.shape[0]
        correct_logprobs = -np.log(probs[np.arange(N), labels] + EPS)
        loss = np.sum(correct_logprobs) / N
        
        # 准确率
        acc = np.mean(np.argmax(probs, axis=1) == labels)
        
        # 存储中间变量供后续梯度计算使用
        self.cache = (Input, probs, labels)

        ############################################################################

        return loss, acc

    def gradient_computing(self):

        ############################################################################
        Input, probs, labels = self.cache
        N = Input.shape[0]

        # Softmax损失对scores的梯度
        dscores = probs
        dscores[np.arange(N), labels] -= 1
        dscores /= N
        
        # 对W和b的梯度
        self.grad_W = np.dot(Input.T, dscores)
        self.grad_b = np.sum(dscores, axis=0, keepdims=True)
        ############################################################################


    def XavierInit(self):
        """
        Initialize the weigths
        """
        raw_std = (2 / (self.num_input + self.num_output))**0.5
        init_std = raw_std * (2**0.5)
        self.W = np.random.normal(0, init_std, (self.num_input, self.num_output))
        self.b = np.random.normal(0, init_std, (1, self.num_output))
