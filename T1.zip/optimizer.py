import numpy as np

class SGD(object):
    def __init__(self, model, learning_rate, momentum=0.0):
        self.model = model
        self.learning_rate = learning_rate
        self.momentum = momentum
        # Initialize velocities for weights and biases to zeros
        self.v_W = np.zeros_like(model.W)
        self.v_b = np.zeros_like(model.b)
    def step(self):
        """One updating step, update weights"""

        layer = self.model
        if layer.trainable:

            ############################################################################
            # TODO: Put your code here
            # Calculate diff_W and diff_b using layer.grad_W and layer.grad_b.
            # You need to add momentum to this.

            # 速度更新(Velocity update)
            # V(t+1) = μ*vt - η* ▽L

            # 权重更新(Weight update)
            # W(t+1) = Wt + v(t+1)
            
            self.v_W = self.momentum * self.v_W - self.learning_rate * layer.grad_W
            layer.W += self.v_W
            
            self.v_b = self.momentum * self.v_b - self.learning_rate * layer.grad_b
            layer.b += self.v_b

            ############################################################################
